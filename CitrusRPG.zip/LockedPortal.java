import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LockedPortal here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LockedPortal extends Portal
{
    /**
     * Act - do whatever the LockedPortal wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    public LockedPortal(String type, String lock)
    {
        super(type, lock);
    }
    
    public void act() 
    {
        // Add your action code here.
    }    
}
